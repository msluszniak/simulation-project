package agh.cs.project.elements;

import agh.cs.project.basics.Vector2d;

public interface IMapElement {
    Vector2d getPosition();
}

