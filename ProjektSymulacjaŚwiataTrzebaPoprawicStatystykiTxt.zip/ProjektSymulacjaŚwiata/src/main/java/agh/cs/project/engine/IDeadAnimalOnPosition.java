package agh.cs.project.engine;

public interface IDeadAnimalOnPosition {
    boolean isAlreadyDead(int date);
}
